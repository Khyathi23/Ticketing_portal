from django.contrib import admin
from .models import Department, Designation, Employee, TicketCategory, Ticket, TicketComment
from .forms import EmployeeForm

admin.site.register(Department)
admin.site.register(Designation)
# admin.site.register(Employee)
admin.site.register(TicketCategory)
admin.site.register(Ticket)
admin.site.register(TicketComment)
# admin.site.register(TicketSubCategory)
class EmployeeAdmin(admin.ModelAdmin):
    form = EmployeeForm

admin.site.register(Employee, EmployeeAdmin)

