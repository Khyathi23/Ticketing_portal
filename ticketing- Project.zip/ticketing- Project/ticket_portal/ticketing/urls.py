from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.login_view, name='login'),
    path('admin-home/', views.admin_home, name='admin_home'),
    path('admin-view-tickets/', views.admin_view_tickets, name='admin_view_tickets'),
    path('user-home/', views.user_home, name='user_home'),
    path('raise-ticket/', views.raise_ticket, name='raise_ticket'),
    path('profile/', views.profile_view, name='profile'),
    path('logout/', views.logout_view, name='logout'),
    path('update-ticket-status/', views.update_ticket_status, name='update_ticket_status'),
    path('assign-to/', views.assign_to_view, name='assign_to'),
    path('assigned-tickets/', views.assigned_tickets_view, name='assigned_tickets'),
    path('all-tickets/', views.all_tickets, name='all_tickets'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)