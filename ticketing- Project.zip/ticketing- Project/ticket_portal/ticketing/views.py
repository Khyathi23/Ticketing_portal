from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout 
from django.contrib import messages
from .models import Employee, Ticket, TicketCategory, CATEGORY_CHOICES
from django.contrib.auth.decorators import login_required
from collections import defaultdict
from django.utils.timezone import localtime
import calendar
from django.contrib.auth.models import User
from datetime import datetime
from django.contrib.auth.decorators import user_passes_test
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect, get_object_or_404


# def login_view(request):
#     if request.method == 'POST':
#         username = request.POST.get('username', '').strip()
#         password = request.POST.get('password', '').strip()

#         if not username or not password:
#             messages.error(request, "Please fill in all fields.")
#             return redirect('login')

#         user = authenticate(request, username=username, password=password)

#         if user is not None:
#             login(request, user)
#             return redirect('home')  # Redirect to home page (to be created)
#         else:
#             messages.error(request, "Invalid username or password.")
#             return redirect('login')

#     return render(request, 'ticketing/login.html')

def login_view(request):
    if request.method == "POST":
        username_input = request.POST.get('username')
        password = request.POST.get('password')

        if not username_input or not password:
            messages.error(request, "Username and password are required.")
            return redirect('login')

        user = None

        # Try authenticating directly with username
        user = authenticate(request, username=username_input, password=password)

        if not user:
            # Try finding employee by emp_id
            try:
                emp = Employee.objects.get(emp_id=username_input)
                user = authenticate(request, username=emp.user.username, password=password)
            except Employee.DoesNotExist:
                pass

        if user:
            login(request, user)
            if user.is_superuser:
                return redirect('admin_home')
            elif Employee.objects.filter(user=user).exists():
                return redirect('user_home')
            else:
                messages.error(request, "User role not recognized.")
        else:
            messages.error(request, "Invalid username/ID or password.")

        return redirect('login')

    return render(request, 'ticketing/login.html')

        
    
    # if request.method == "POST":
    #     # import pdb;pdb.set_trace()
    #     username = request.POST.get('username')
    #     password = request.POST.get('password')

    #     if username and password:


    #         # Try Django authentication first
    #         user=User.objects.get(username=username)
    #         user = authenticate(request, username=username, password=password)

    #         if user:
    #             if user.is_superuser:
    #                 return redirect('admin_home')
    #             else:
    #                 return redirect('user_home')
    #         else:
    #             messages.error(request, "Invalid username or password.")

        # if user:
        #     login(request, user)
        #     if user.is_superuser:
        #         return redirect('admin_home')
        #     elif Employee.objects.filter(user=user).exists():
        #         return redirect('user_home')
        #     else:
        #         messages.error(request, "User role not recognized.")
        #         return redirect('login')

        # # If not authenticated, try checking Employee manually
        # try:
        #     emp = Employee.objects.get(emp_id=username)
        #     if emp.password == password:  # Not secure, but matches your structure
        #         login(request, emp.user)
        #         return redirect('user_home')
        #     else:
        #         messages.error(request, "Invalid username or password.")
        # except Employee.DoesNotExist:
        #     messages.error(request, "Invalid username or password.")

    #     return redirect('login')

    # return render(request, 'ticketing/login.html')


# def admin_home(request):
#     return render(request, 'ticketing/admin_home.html')


# def user_home(request):
#     return render(request, 'ticketing/user_home.html')

# def raise_ticket(request):
#     return render(request, 'ticketing/raise_ticket.html')

def profile_view(request):
    return render(request, 'ticketing/profile.html')  # Add page later

def logout_view(request):
    logout(request)
    return redirect('login')

# def user_home(request):
#     user = request.user
#     tickets = Ticket.objects.filter(created_by=user)
#     selected_month = request.GET.get("month")
#     all_tickets = Ticket.objects.filter(created_by=user)
    
#     months = Ticket.objects.dates('created_at', 'month', order='DESC')
#     months = [m.strftime("%B") for m in months]
    
#     if selected_month:
#         month_number = list(calendar.month_name).index(selected_month)
#         tickets = Ticket.objects.filter(created_by=user)
#     else:
#         tickets = all_tickets

#     active_count = Ticket.objects.filter(created_by=user, status__in=['Open', 'In Progress']).count()
#     solved_count = Ticket.objects.filter(created_by=user, status__in=['Resolved', 'Closed']).count()
#     on_hold_count = Ticket.objects.filter(created_by=user, status='On Hold').count()
#     total_count = Ticket.objects.filter(created_by=user).count()
    
#     date_wise = defaultdict(lambda: {"Raised": 0, "Solved": 0, "On Hold": 0})
#     for t in tickets:
#         date = localtime(t.created_at).strftime('%Y-%m-%d')
#         if t.status in ['Resolved', 'Closed']:
#             date_wise[date]['Solved'] += 1
#         elif t.status == 'On Hold':
#             date_wise[date]['On Hold'] += 1
#         else:
#             date_wise[date]['Raised'] += 1

#     sorted_dates = sorted(date_wise.keys())
#     raised_data = [date_wise[d]['Raised'] for d in sorted_dates]
#     solved_data = [date_wise[d]['Solved'] for d in sorted_dates]
#     on_hold_data = [date_wise[d]['On Hold'] for d in sorted_dates]

#     # Pie chart totals
#     raised_total = tickets.exclude(status__in=['Resolved', 'Closed', 'On Hold']).count()
#     solved_total = tickets.filter(status__in=['Resolved', 'Closed']).count()
#     on_hold_total = tickets.filter(status='On Hold').count()

#     # Get available months
#     months = sorted(set(ticket.created_at.strftime('%B') for ticket in Ticket.objects.filter(created_by=user)))

#     context = {
#         'active_count': active_count,
#         'solved_count': solved_count,
#         'on_hold_count': on_hold_count,
#         'total_count': total_count,
#         'dates': sorted_dates,
#         'raised_data': raised_data,
#         'solved_data': solved_data,
#         'on_hold_data': on_hold_data,
#         'raised_total': raised_total,
#         'solved_total': solved_total,
#         'on_hold_total': on_hold_total,
#         'months': months,
#         'selected_month': selected_month,
#     }
#     return render(request, 'ticketing/user_home.html', context)

# @login_required
# def user_home(request):
#     user = request.user
#     all_tickets = Ticket.objects.filter(created_by=user)

#     # Get selected month and year from query params
#     selected_month = request.GET.get('month')
#     selected_year = request.GET.get('year')

#     # Full list of months and fixed year range
#     months = list(calendar.month_name)[1:]  # Jan to Dec
#     years = [str(y) for y in range(2024, 2031)]

#     # Apply filter based on month and year
#     filtered_tickets = all_tickets
#     if selected_month and selected_year:
#         month_index = list(calendar.month_name).index(selected_month)
#         filtered_tickets = filtered_tickets.filter(created_at__month=month_index, created_at__year=int(selected_year))

#     # Dashboard counts
#     active_count = filtered_tickets.filter(status__in=['Open', 'In Progress']).count()
#     solved_count = filtered_tickets.filter(status__in=['Resolved', 'Closed']).count()
#     on_hold_count = filtered_tickets.filter(status='On Hold').count()
#     total_count = filtered_tickets.count()

#     # Graph data by date
#     date_wise = defaultdict(lambda: {"Raised": 0, "Solved": 0, "On Hold": 0})
#     for ticket in filtered_tickets:
#         date = localtime(ticket.created_at).strftime('%Y-%m-%d')
#         if ticket.status in ['Resolved', 'Closed']:
#             date_wise[date]['Solved'] += 1
#         elif ticket.status == 'On Hold':
#             date_wise[date]['On Hold'] += 1
#         else:
#             date_wise[date]['Raised'] += 1

#     sorted_dates = sorted(date_wise.keys())
#     raised_data = [date_wise[d]['Raised'] for d in sorted_dates]
#     solved_data = [date_wise[d]['Solved'] for d in sorted_dates]
#     on_hold_data = [date_wise[d]['On Hold'] for d in sorted_dates]

#     # Pie chart
#     raised_total = filtered_tickets.exclude(status__in=['Resolved', 'Closed', 'On Hold']).count()
#     solved_total = filtered_tickets.filter(status__in=['Resolved', 'Closed']).count()
#     on_hold_total = filtered_tickets.filter(status='On Hold').count()

#     # Table data
#     ticket_table = filtered_tickets.order_by('-created_at')

#     context = {
#         'active_count': active_count,
#         'solved_count': solved_count,
#         'on_hold_count': on_hold_count,
#         'total_count': total_count,
#         'dates': sorted_dates,
#         'raised_data': raised_data,
#         'solved_data': solved_data,
#         'on_hold_data': on_hold_data,
#         'raised_total': raised_total,
#         'solved_total': solved_total,
#         'on_hold_total': on_hold_total,
#         'months': months,
#         'years': years,
#         'selected_month': selected_month,
#         'selected_year': selected_year,
#         'ticket_table': ticket_table,
#     }
#     return render(request, 'ticketing/user_home.html', context)
# import calendar

# def user_home(request):
#     user = request.user
#     selected_month = request.GET.get("month")
#     selected_year = request.GET.get("year")

#     tickets = Ticket.objects.filter(created_by=user)

#     if selected_month and selected_year:
#         month_number = list(calendar.month_name).index(selected_month)
#         tickets = tickets.filter(created_at__month=month_number, created_at__year=int(selected_year))

#     # Dashboard stats
#     active_count = tickets.filter(status__in=['Open', 'In Progress']).count()
#     solved_count = tickets.filter(status__in=['Resolved', 'Closed']).count()
#     on_hold_count = tickets.filter(status='On Hold').count()
#     total_count = tickets.count()

#     # Graph data
#     from collections import defaultdict
#     from django.utils.timezone import localtime
#     date_wise = defaultdict(lambda: {"Raised": 0, "Solved": 0, "On Hold": 0})

#     for t in tickets:
#         date = localtime(t.created_at).strftime('%Y-%m-%d')
#         if t.status in ['Resolved', 'Closed']:
#             date_wise[date]['Solved'] += 1
#         elif t.status == 'On Hold':
#             date_wise[date]['On Hold'] += 1
#         else:
#             date_wise[date]['Raised'] += 1

#     sorted_dates = sorted(date_wise.keys())
#     raised_data = [date_wise[d]['Raised'] for d in sorted_dates]
#     solved_data = [date_wise[d]['Solved'] for d in sorted_dates]
#     on_hold_data = [date_wise[d]['On Hold'] for d in sorted_dates]

#     raised_total = tickets.exclude(status__in=['Resolved', 'Closed', 'On Hold']).count()
#     solved_total = tickets.filter(status__in=['Resolved', 'Closed']).count()
#     on_hold_total = tickets.filter(status='On Hold').count()

#     context = {
#         'active_count': active_count,
#         'solved_count': solved_count,
#         'on_hold_count': on_hold_count,
#         'total_count': total_count,
#         'dates': sorted_dates,
#         'raised_data': raised_data,
#         'solved_data': solved_data,
#         'on_hold_data': on_hold_data,
#         'raised_total': raised_total,
#         'solved_total': solved_total,
#         'on_hold_total': on_hold_total,
#         'selected_month': selected_month,
#         'selected_year': selected_year,
#         'months': list(calendar.month_name)[1:],  # ['January', ..., 'December']
#         'years': list(range(2024, 2031)),         # [2024, 2025, ..., 2030]
#         'filtered_tickets': tickets,
#     }
#     return render(request, 'ticketing/user_home.html', context)

# 

from datetime import datetime
from collections import defaultdict
from django.utils.timezone import localtime
from django.shortcuts import render
from .models import Ticket

def user_home(request):
    user = request.user
    all_tickets = Ticket.objects.filter(created_by=user)

    selected_month = request.GET.get('month')
    selected_year = request.GET.get('year')

    # Filter tickets based on month and year
    if selected_month and selected_year:
        month_num = datetime.strptime(selected_month, "%B").month
        year_int = int(selected_year)
        tickets = all_tickets.filter(created_at__month=month_num, created_at__year=year_int)
    else:
        tickets = all_tickets

    # Counts
    active_count = tickets.filter(status__in=['Open', 'In Progress']).count()
    solved_count = tickets.filter(status__in=['Solved', 'Closed']).count()
    on_hold_count = tickets.filter(status='On Hold').count()
    total_count = tickets.count()

    # Chart Data
    date_wise = defaultdict(lambda: {"Active": 0, "Solved": 0, "On Hold": 0})
    for t in tickets:
        created_date = localtime(t.created_at).strftime('%Y-%m-%d')

        if t.status in ['Open', 'In Progress']:
            date_wise[created_date]['Active'] += 1
        elif t.status == 'On Hold':
            date_wise[created_date]['On Hold'] += 1
        elif t.status in ['Solved', 'Closed']:
            solved_date = localtime(t.solved_at).strftime('%Y-%m-%d') if t.solved_at else created_date
            date_wise[solved_date]['Solved'] += 1

    sorted_dates = sorted(date_wise.keys())
    active_data = [date_wise[d]['Active'] for d in sorted_dates]
    solved_data = [date_wise[d]['Solved'] for d in sorted_dates]
    on_hold_data = [date_wise[d]['On Hold'] for d in sorted_dates]

    # Pie Chart Totals
    active_total = active_count
    solved_total = solved_count
    on_hold_total = on_hold_count

    # Dropdown values
    months = [datetime(2000, i, 1).strftime('%B') for i in range(1, 13)]
    years = list(range(2020, 2026))  # Customize range as needed

    context = {
        'dates': sorted_dates,
        'active_data': active_data,
        'solved_data': solved_data,
        'on_hold_data': on_hold_data,
        'active_total': active_total,
        'solved_total': solved_total,
        'on_hold_total': on_hold_total,
        'active_count': active_count,
        'solved_count': solved_count,
        'on_hold_count': on_hold_count,
        'total_count': total_count,
        'months': months,
        'years': years,
        'selected_month': selected_month,
        'selected_year': selected_year,
        'filtered_tickets': tickets,
    }
    return render(request, 'ticketing/user_home.html', context)


# @login_required
# def raise_ticket(request):
#     if request.method == 'POST':
#         title = request.POST.get('title')
#         description = request.POST.get('description')
#         category = request.POST.get('category')
#         # subcategory = request.POST.get('subcategory')
#         priority = request.POST.get('priority')
#         assigned_to_id = request.POST.get('assigned_to')
#         cc_to_id = request.POST.get('cc_to')
#         attachment = request.FILES.get('attachment')
#         subcategory_id = request.POST.get('subcategory')

#         assigned_to = User.objects.get(id=assigned_to_id) if assigned_to_id else None
#         cc_to = User.objects.get(id=cc_to_id) if cc_to_id else None

#         Ticket.objects.create(
#             title=title,
#             description=description,
#             category=category,
#             priority=priority,
#             created_by=request.user,
#             assigned_to=assigned_to,
#             attachment=attachment,
#             subcategory=SubCategory,
#         )
#         return redirect('user_home')

#     users = User.objects.exclude(id=request.user.id)
#     categories = CATEGORY_CHOICES
#     subcategories = SubCategory.objects.all()

#     return render(request, 'ticketing/raise_ticket.html', {'categories': categories, 'users': users,})


@login_required
def raise_ticket(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        category = request.POST.get('category')
        subcategory = request.POST.get('subcategory')  # ✔️ Just get string, no model lookup
        priority = request.POST.get('priority')
        assigned_to_id = request.POST.get('assigned_to')
        cc_to_id = request.POST.get('cc_to')
        attachment = request.FILES.get('attachment')

        assigned_to = User.objects.get(id=assigned_to_id) if assigned_to_id else None
        cc_to = User.objects.get(id=cc_to_id) if cc_to_id else None

        Ticket.objects.create(
            title=title,
            description=description,
            category=category,
            subcategory=subcategory,  # ✔️ Just save the string
            priority=priority,
            created_by=request.user,
            # assigned_to=assigned_to,
            # cc_to=cc_to,
            attachment=attachment
        )

        return redirect('user_home')

    users = User.objects.exclude(id=request.user.id)
    categories = CATEGORY_CHOICES

    return render(request, 'ticketing/raise_ticket.html', {
        'categories': categories,
        'users': users
    })


# categories = CATEGORY_CHOICES

@login_required
def profile_view(request):
    employee = request.user.employee  # assuming OneToOneField

    if request.method == "POST":

        # 1. Update Profile Picture
        if 'update_picture' in request.POST:
            profile_pic = request.FILES.get('profile_pic')
            if profile_pic:
                employee.profile_pic = profile_pic
                employee.save()
            return redirect('profile')

        # 2. Delete Profile Picture
        elif 'delete_picture' in request.POST:
            if employee.profile_pic:
                employee.profile_pic.delete(save=True)
            return redirect('profile')

        # 3. Update Employee Details
        elif 'update_details' in request.POST:
            employee.name = request.POST.get('name')
            employee.phone = request.POST.get('phone')
            employee.department = request.POST.get('department')
            employee.designation = request.POST.get('designation')
            employee.location = request.POST.get('location')
            employee.save()
            return redirect('profile')

        # 4. Change Password
        elif 'change_password' in request.POST:
            old_password = request.POST.get('old_password')
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')

            if request.user.check_password(old_password):
                if new_password == confirm_password:
                    request.user.set_password(new_password)
                    request.user.save()
                    update_session_auth_hash(request, request.user)
                    return redirect('profile')
                else:
                    return render(request, 'ticketing/profile.html', {
                        'employee': employee,
                        'error': 'New passwords do not match.'
                    })
            else:
                return render(request, 'ticketing/profile.html', {
                    'employee': employee,
                    'error': 'Old password is incorrect.'
                })

    return render(request, 'ticketing/profile.html', {'employee': employee})



# Utility to check if user is admin
def is_admin(user):
    return user.is_superuser

from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import render
from django.utils.timezone import localtime
from collections import defaultdict
import calendar
from .models import Ticket  # adjust this import if needed

def is_admin(user):
    return user.is_superuser  # or custom admin check logic

@user_passes_test(is_admin)
def admin_home(request):
    # Filters
    month = request.GET.get('month')
    year = request.GET.get('year')

    tickets = Ticket.objects.all()

    if month and year:
        month_number = list(calendar.month_name).index(month)
        tickets = tickets.filter(created_at__month=month_number, created_at__year=int(year))

    # Dashboard counts
    active_count = tickets.filter(status__in=['Open', 'In Progress']).count()
    solved_count = tickets.filter(status__in=['Solved', 'Closed']).count()
    on_hold_count = tickets.filter(status='On Hold').count()
    total_count = tickets.count()

    # Graph Data: Date-wise active, solved, on hold
    date_wise = defaultdict(lambda: {"Active": 0, "Solved": 0, "On Hold": 0})

    for t in tickets:
        created_date = localtime(t.created_at).date()
        if t.status in ['Solved', 'Closed']:
            solved_date = localtime(t.solved_at).date() if t.solved_at else created_date
            date_wise[solved_date]["Solved"] += 1
        elif t.status == 'On Hold':
            date_wise[created_date]["On Hold"] += 1
        elif t.status in ['Open', 'In Progress']:
            date_wise[created_date]["Active"] += 1

    sorted_dates = sorted(date_wise.keys())
    date_labels = [d.strftime("%d %b") for d in sorted_dates]

    active_data = [date_wise[d]["Active"] for d in sorted_dates]
    solved_data = [date_wise[d]["Solved"] for d in sorted_dates]
    on_hold_data = [date_wise[d]["On Hold"] for d in sorted_dates]

    # Pie chart data
    active_total = active_count
    solved_total = solved_count
    on_hold_total = on_hold_count

    recent_tickets = tickets.order_by('-created_at')[:10]

    context = {
        'filtered_tickets': recent_tickets,
        'active_count': active_count,
        'solved_count': solved_count,
        'on_hold_count': on_hold_count,
        'total_count': total_count,
        'dates': date_labels,
        'active_data': active_data,
        'solved_data': solved_data,
        'on_hold_data': on_hold_data,
        'active_total': active_total,
        'solved_total': solved_total,
        'on_hold_total': on_hold_total,
        'months': list(calendar.month_name)[1:],  # Jan–Dec
        'years': list(range(2020, 2026)),
        'selected_month': month,
        'selected_year': year,
    }

    return render(request, 'ticketing/admin_home.html', context)




# @user_passes_test(is_admin)
# def admin_home(request):
#     # Filter logic
#     month = request.GET.get('month')
#     year = request.GET.get('year')

#     tickets = Ticket.objects.all()
#     if month and year:
#         month_number = list(calendar.month_name).index(month)
#         tickets = tickets.filter(created_at__month=month_number, created_at__year=year)

#     # Dashboard counts
#     active_count = tickets.filter(status__in=['Open', 'In Progress']).count()
#     solved_count = tickets.filter(status='Solved').count()
#     on_hold_count = tickets.filter(status='On Hold').count()
#     total_count = tickets.count()

#     # Graph data
#     dates = sorted(list(set(tickets.values_list('created_at__date', flat=True))))
#     date_labels = [d.strftime("%d %b") for d in dates]

#     def get_daily_counts(status_type):
#         return [tickets.filter(created_at__date=d, status=status_type).count() for d in dates]

#     raised_data = [tickets.filter(created_at__date=d).count() for d in dates]
#     solved_data = get_daily_counts('Solved')
#     on_hold_data = get_daily_counts('On Hold')
#     recent_tickets = Ticket.objects.all().order_by('-created_at')[:10]
#     context = {
#         'filtered_tickets': recent_tickets,
#         'active_count': active_count,
#         'solved_count': solved_count,
#         'on_hold_count': on_hold_count,
#         'total_count': total_count,
#         'dates': date_labels,
#         'raised_data': raised_data,
#         'solved_data': solved_data,
#         'on_hold_data': on_hold_data,
#         'raised_total': tickets.count(),
#         'solved_total': solved_count,
#         'on_hold_total': on_hold_count,
#         'months': list(calendar.month_name)[1:],
#         'years': [y for y in range(2020, 2026)],
#         'selected_month': month,
#         'selected_year': year,
#     }
    
#     return render(request, 'ticketing/admin_home.html', context)



# @user_passes_test(is_admin)
# def admin_view_tickets(request):
#     tickets = Ticket.objects.all().order_by('-created_at')
#     return render(request, 'ticketing/admin_view_tickets.html', {'tickets': tickets})


@login_required
@user_passes_test(lambda u: u.is_superuser)
def admin_view_tickets(request):
    tickets = Ticket.objects.all()

    # Optional: filter by month/year
    month = request.GET.get('month')
    year = request.GET.get('year')

    if month and year:
        tickets = tickets.filter(created_at__month=datetime.strptime(month, '%B').month,
                                 created_at__year=int(year))

    context = {
        'filtered_tickets': tickets,
        'months': [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ],
        'years': range(2020, 2026),
        'selected_month': month,
        'selected_year': year,
        'active_count': tickets.filter(status__in=["Open", "In Progress"]).count(),
        'solved_count': tickets.filter(status="Solved").count(),
        'on_hold_count': tickets.filter(status="On Hold").count(),
        'total_count': tickets.count(),
    }
    return render(request, 'ticketing/admin_home.html', context)


@csrf_exempt
@user_passes_test(lambda u: u.is_superuser)
def update_ticket_status(request):
    if request.method == "POST":
        ticket_id = request.POST.get("ticket_id")
        new_status = request.POST.get("status")
        ticket = get_object_or_404(Ticket, id=ticket_id)
        ticket.status = new_status
        ticket.save()
    return redirect('admin_home')

def assign_to_view(request):
    return render(request, 'ticketing/assign_to.html')

def assigned_tickets_view(request):
    return render(request, 'ticketing/assigned_tickets.html')

def all_tickets(request):
    # fetch all ticket objects
    tickets = Ticket.objects.all().order_by('-id')  # or by date
    return render(request, 'ticketing/all_tickets.html', {'tickets': tickets})
