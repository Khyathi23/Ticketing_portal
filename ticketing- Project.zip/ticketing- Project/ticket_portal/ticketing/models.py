from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

# Department model
class Department(models.Model):
    department = models.CharField(max_length=100)

    def __str__(self):
        return self.department

# Designation model
class Designation(models.Model):
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    designation = models.CharField(max_length=50)
    role = models.CharField(
        max_length=100,
        choices=[
            ('Employee', 'Employee'),
            ('Manager', 'Manager'),
            ('Director', 'Director'),
        ]
    )

    def __str__(self):
        return self.designation

# Employee model
class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    emp_id = models.CharField(max_length=30, unique=True, primary_key=True)
    emp_mail = models.EmailField(null=True, blank=True)
    emp_dep = models.ForeignKey(Department, on_delete=models.CASCADE)
    emp_des = models.ForeignKey(Designation, on_delete=models.CASCADE)
    # password = models.CharField(max_length=100, null=True, blank=True)
    # confirm_password = models.CharField(max_length=100, null=True, blank=True)
    profile_pic = models.ImageField(upload_to='profile_pics/', null=True, blank=True)

    def __str__(self):
        return self.user.get_full_name()

# TicketCategory model
CATEGORY_CHOICES = [
    ('Hardware', 'Hardware'),
    ('Network', 'Network'),
    ('Software', 'Software'),
    ('Access', 'Access & Permissions'),
    ('Email', 'Email & Communication'),
    ('Cloud', 'Cloud Services'),
    ('Maintenance', 'Maintenance & Support'),
    ('Security', 'Security'),
    ('Data', 'Data & Storage'),
    ('General', 'General Inquiry'),
]

class TicketCategory(models.Model):
    ticketcategory = models.CharField(max_length=100, choices=CATEGORY_CHOICES)

    def __str__(self):
        return self.ticketcategory

# class Category(models.Model):
#     name = models.CharField(max_length=100)

#     def __str__(self):
#         return self.name

# class SubCategory(models.Model):
#     category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
#     name = models.CharField(max_length=100)

#     def __str__(self):
#         return self.name

# Ticket model
PRIORITY_CHOICES = [
    ('Low', 'Low'),
    ('Medium', 'Medium'),
    ('High', 'High'),
    ('Critical', 'Critical'),
]

STATUS_CHOICES = [
    ('Open', 'Open'),
    ('In Progress', 'In Progress'),
    ('Solved', 'Solved'),
    ('Closed', 'Closed'),
    ('On Hold', 'On Hold'),
]

class Ticket(models.Model):
    title = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='Medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Open')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_tickets')
    assigned_to = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='assigned_tickets')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolution_comment = models.TextField(null=True, blank=True)
    attachment = models.FileField(upload_to='ticket_attachments/', null=True, blank=True)
    subcategory = models.CharField(max_length=100, null=True, blank=True)
    solved_at = models.DateTimeField(null=True, blank=True) 

    def __str__(self):
        return f"{self.title} ({self.status})"

# TicketComment model
class TicketComment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Comment by {self.user.username} on {self.ticket.title}"
    
# class TicketSubCategory(models.Model):
#     category = models.ForeignKey(TicketCategory, on_delete=models.CASCADE, related_name='subcategories')
#     name = models.CharField(max_length=100)

#     def __str__(self):
#         return f"{self.name} ({self.category.ticketcategory})"
